require("./config/env.config");
//const MongoDBHelper = require('./mongodbhelper');
const mongoose = require('mongoose');
const config = require('./config/config');
const logger = require('./logging/logModule');
const util = require('util');
var TwilioClient = require('./twilio/twilioClient');
const sendMessagesAsync = util.promisify(TwilioClient.sendMessages);
const Contacts = require('../models/contactsModel');

//const db = new MongoDBHelper('mongodb+srv://<username>:<password>@cluster0.mongodb.net/test?retryWrites=true&w=majority');
//await db.connect();
//const result = await db.find('test', 'contacts', {});
//console.log(result);
//await db.close();

// DB
mongoose.Promise = global.Promise;
mongoose.connect(config.getDbConnectionString());
logger.info("############### => getDbConnectionString = "+config.getDbConnectionString());

logger.info('Jay Swaminarayan, First log ! :D ');
logger.info('<<<>>>> config.TWILIO_ACCOUNT_SID='+config.TWILIO_ACCOUNT_SID);

export const handler = async (event) => {
    // TODO implement
    console.log('krutik event = '+ JSON.stringify(event));
    //for (const message of event.Records) {
    const message = event.Records[0];
    console.log(`krutik Processed message ${message.body}`);
    
    //
    var userId = message.body.userId;
    var group = message.body.groupName;
    var includeName = message.body.includeName;
    var textmessage  = message.body.textmessage;
    var isFailed = false;

    try{
      contacts = await Contacts.find({ _userId: userId, groups: group});//, function(err, contacts){
  
    }catch(err){
      logger.error('[handler] error finding contacts with given criteria. error from DB = '+err.message + ' \nStack = '+err.stack);
      isFailed = true;
    }

    logger.info('[] total contacts in group -> '+ group + ' = ' + contacts.length);
    logger.info('[] textmessage = '+ textmessage);

    try{   
      //send messages
      const remainingMessageCount = await sendMessagesAsync(contacts, userId, remainingMessages, message,"",includeName);//function(err,remainingMessages) {
      logger.info('[contactsController][post:/smsapi/users/:userId/groups/:groupName/sendsms] Messages on their way! . remainingMessageCount='+remainingMessageCount);
    }catch(err) {
      logger.error('[contactsController][post:/smsapi/users/:userId/groups/:groupName/sendsms] error sending messages. error from DB = '+err + ' \nStack = '+err.stack);
    }
    //
    const response = {
      statusCode: 200,
      body: JSON.stringify('Hello from Lambda!'),
    };
    return response;
};